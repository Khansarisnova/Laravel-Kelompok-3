

<?php $__env->startSection('content'); ?>

  <h1>Edit Data Mahasiswa</h1>
      <?php if(session('Suksess')): ?>
      <div class="alert alert-success" role="alert">
        <?php echo e(session('Suksess')); ?>

      </div>
      <?php endif; ?>
        <div class="row">
            <div class="col lg 12">
            <form action="/Mahasiswa/<?php echo e($Mahasiswa->id); ?>/Update" method="POST">
                <?php echo e(csrf_field()); ?>

                  <div class="form-group">
                    <label for="exampleInputEmail1" class="form-label">Nim</label>
                    <input name="nim" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($Mahasiswa->nim); ?>">
                  </div>
                  <div class="form-group">
                      <label for="exampleInputEmail1" class="form-label">Nama Lengkap</label>
                      <input name="nama_lengkap" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($Mahasiswa->nama_lengkap); ?>">
                    </div>
                    <div class="form-group">
                        <label for="jurusan">PILIH JURUSAN</label>
                        <select name="jurusan" class="form-control" id="jurusan">
                          <option value="S1 - Fisioterapi" <?php if($Mahasiswa->jurusan == 'S1 - Fisioterapi'): ?> selected <?php endif; ?>>S1 - Fisioterapi</option>
                          <option value="D4 - Akupuntur dan Pengobatan Herbal" <?php if($Mahasiswa->jurusan == 'D4 - Akupuntur dan Pengobatan Herbal'): ?> selected <?php endif; ?>>D4 - Akupuntur dan Pengobatan Herbal</option>
                          <option value="S1 - Pendidikan Bahasa Arab" <?php if($Mahasiswa->jurusan == 'S1 - Pendidikan Bahasa Arab'): ?> selected <?php endif; ?>>S1 - Pendidikan Bahasa Arab</option>
                          <option value="S1 - Pendidikan Kepelatihan Olah Raga" <?php if($Mahasiswa->jurusan == 'S1 - Pendidikan Kepelatihan Olah Raga'): ?> selected <?php endif; ?>>S1 - Pendidikan Kepelatihan Olah Raga</option>
                          <option value="D4 - Keperawatan Anestesiologi" <?php if($Mahasiswa->jurusan == 'D4 - Keperawatan Anestesiologi'): ?> selected <?php endif; ?>>D4 - Keperawatan Anestesiologi</option>
                          <option value="D4 - Teknologi Radiologi Pencitraan" <?php if($Mahasiswa->jurusan == 'D4 - Teknologi Radiologi Pencitraan'): ?> selected <?php endif; ?>>D4 - Teknologi Radiologi Pencitraan</option>
                          <option value="S1 - Informatika" <?php if($Mahasiswa->jurusan == 'S1 - Informatika'): ?> selected <?php endif; ?>>S1 - Informatika</option>
                          <option value="S1 - Teknik Komputer" <?php if($Mahasiswa->jurusan == 'S1 - Teknik Komputer'): ?> selected <?php endif; ?>>S1 - Teknik Komputer</option>
                          <option value="S1 - Peternakan" <?php if($Mahasiswa->jurusan == 'S1 - Peternakan'): ?> selected <?php endif; ?>>S1 - Peternakan</option>
                          <option value="D3 - Produksi Ternak" <?php if($Mahasiswa->jurusan == 'D3 - Produksi Ternak'): ?> selected <?php endif; ?>>D3 - Produksi Ternak</option>
                          <option value="S1 - Bisnis Digital" <?php if($Mahasiswa->jurusan == 'S1 - Bisnis Digital'): ?> selected <?php endif; ?>>S1 - Bisnis Digital</option>
                          <option value="S1 - Akutansi" <?php if($Mahasiswa->jurusan == 'S1 - Akutansi'): ?> selected <?php endif; ?>>S1 - Akutansi</option>
                          <option value="S1 - Ilmu Komunikasi" <?php if($Mahasiswa->jurusan == 'S1 - Ilmu Komunikasi'): ?> selected <?php endif; ?>>S1 - Ilmu Komunikasi</option>
                          <option value="D3 - Perhotelan" <?php if($Mahasiswa->jurusan == 'D3 - Perhotelan'): ?> selected <?php endif; ?>>D3 - Perhotelan</option>
                          <option value="S1 - Hukum Bisnis" <?php if($Mahasiswa->jurusan == 'S1 - Hukum Bisnis'): ?> selected <?php endif; ?>>S1 - Hukum Bisnis</option>
                        </select>
                      </div>
                      
                      <div class="form-group">
                        <label for="fakultas">PILIH FAKULTAS</label>
                        <select name="fakultas" class="form-control" id="fakultas">
                          <option value="Kesehatan dan Pendidikan" <?php if($Mahasiswa->fakultas == 'Kesehatan dan Pendidikan'): ?> selected <?php endif; ?>>Kesehatan dan Pendidikan</option>
                          <option value="Sains dan Teknologi" <?php if($Mahasiswa->fakultas == 'Sains dan Teknologi'): ?> selected <?php endif; ?>>Sains dan Teknologi</option>
                          <option value="Komunikasi dan Bisnis" <?php if($Mahasiswa->fakultas == 'Komunikasi dan Bisnis'): ?> selected <?php endif; ?>>Komunikasi dan Bisnis</option>
                        </select>
                      </div>
                      
                      <div class="form-group">
                        <label for="jenis_kelamin">PILIH JENIS KELAMIN</label>
                        <select name="jenis_kelamin" class="form-control" id="jenis_kelamin">
                          <option value="Laki-laki" <?php if($Mahasiswa->jenis_kelamin == 'Laki-laki'): ?> selected <?php endif; ?>>Laki-laki</option>
                          <option value="Perempuan" <?php if($Mahasiswa->jenis_kelamin == 'Perempuan'): ?> selected <?php endif; ?>>Perempuan</option>
                        </select>
                      </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1" class="form-label">Alamat</label>
                      <input name="alamat" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($Mahasiswa->alamat); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1" class="form-label">Email</label>
                      <input name="email" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($Mahasiswa->email); ?>">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1" class="form-label">Angkatan</label>
                      <input name="angkatan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($Mahasiswa->angkatan); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Update</button>
               </form>
            </div>
        </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Project1-Khansa\resources\views/Mahasiswa/Edit.blade.php ENDPATH**/ ?>
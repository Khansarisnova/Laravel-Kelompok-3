

<?php $__env->startSection('content'); ?>

      <?php if(session('Suksess')): ?>
      <div class="alert alert-success" role="alert">
        <?php echo e(session('Suksess')); ?>

      </div>
      <?php endif; ?>
        <div class="row">
            <div class="col-6">
                <h1>Data Mahasiswa</h1>
            </div>     
                    </div>
                  </div>
            </div>
            
            <table class="table table-hover">
            <tr>
                <th>NIM</th>
                <th>NAMA LENGKAP</th>
                <th>JURUSAN</th>
                <th>FAKULTAS</th>
                <th>JENIS KELAMIN</th>
                <th>ALAMAT</th>
                <th>EMAIL</th>
                <th>ANGKATAN</th>
                <th>AKSI</th>
            </tr>
            <?php $__currentLoopData = $data_Mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($Mahasiswa->nim); ?></td>
                <td><?php echo e($Mahasiswa->nama_lengkap); ?></td>
                <td><?php echo e($Mahasiswa->Jurusan); ?></td>
                <td><?php echo e($Mahasiswa->Fakultas); ?></td>
                <td><?php echo e($Mahasiswa->jenis_kelamin); ?></td>
                <td><?php echo e($Mahasiswa->alamat); ?></td>
                <td><?php echo e($Mahasiswa->email); ?></td>
                <td><?php echo e($Mahasiswa->angkatan); ?></td>
                <td><a href="/Mahasiswa/<?php echo e($Mahasiswa->id); ?>/Edit" class="btn btn-primary btn-sm">Edit</a></td>
                <td><a href="/Mahasiswa/<?php echo e($Mahasiswa->id); ?>/Delete" class="btn btn-secondary btn-sm" onclick="return confirm ('Yakin Mau Dihapus')">Delete</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div class="col-6">
            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal">
                TAMBAH DATA
              </button>
              
              <!-- Modal -->
              <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">TAMBAH DATA MAHASISWA</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="/Mahasiswa/create" method="POST">
                          <?php echo e(csrf_field()); ?>

                            <div class="mb-3">
                              <label for="exampleInputEmail1" class="form-label">Nim</label>
                              <input name="nim" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Nama Lengkap</label>
                                <input name="nama_lengkap" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                              </div>
                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Jurusan</label>
                                <select name="jurusan" class="form-control" id="jurusan">
                                  <option value="S1 - Fisioterapi" <?php if($Mahasiswa->jurusan == 'S1 - Fisioterapi'): ?> selected <?php endif; ?>>S1 - Fisioterapi</option>
                                  <option value="D4 - Akupuntur dan Pengobatan Herbal" <?php if($Mahasiswa->jurusan == 'D4 - Akupuntur dan Pengobatan Herbal'): ?> selected <?php endif; ?>>D4 - Akupuntur dan Pengobatan Herbal</option>
                                  <option value="S1 - Pendidikan Bahasa Arab" <?php if($Mahasiswa->jurusan == 'S1 - Pendidikan Bahasa Arab'): ?> selected <?php endif; ?>>S1 - Pendidikan Bahasa Arab</option>
                                  <option value="S1 - Pendidikan Kepelatihan Olah Raga" <?php if($Mahasiswa->jurusan == 'S1 - Pendidikan Kepelatihan Olah Raga'): ?> selected <?php endif; ?>>S1 - Pendidikan Kepelatihan Olah Raga</option>
                                  <option value="D4 - Keperawatan Anestesiologi" <?php if($Mahasiswa->jurusan == 'D4 - Keperawatan Anestesiologi'): ?> selected <?php endif; ?>>D4 - Keperawatan Anestesiologi</option>
                                  <option value="D4 - Teknologi Radiologi Pencitraan" <?php if($Mahasiswa->jurusan == 'D4 - Teknologi Radiologi Pencitraan'): ?> selected <?php endif; ?>>D4 - Teknologi Radiologi Pencitraan</option>
                                  <option value="S1 - Informatika" <?php if($Mahasiswa->jurusan == 'S1 - Informatika'): ?> selected <?php endif; ?>>S1 - Informatika</option>
                                  <option value="S1 - Teknik Komputer" <?php if($Mahasiswa->jurusan == 'S1 - Teknik Komputer'): ?> selected <?php endif; ?>>S1 - Teknik Komputer</option>
                                  <option value="S1 - Peternakan" <?php if($Mahasiswa->jurusan == 'S1 - Peternakan'): ?> selected <?php endif; ?>>S1 - Peternakan</option>
                                  <option value="D3 - Produksi Ternak" <?php if($Mahasiswa->jurusan == 'D3 - Produksi Ternak'): ?> selected <?php endif; ?>>D3 - Produksi Ternak</option>
                                  <option value="S1 - Bisnis Digital" <?php if($Mahasiswa->jurusan == 'S1 - Bisnis Digital'): ?> selected <?php endif; ?>>S1 - Bisnis Digital</option>
                                  <option value="S1 - Akutansi" <?php if($Mahasiswa->jurusan == 'S1 - Akutansi'): ?> selected <?php endif; ?>>S1 - Akutansi</option>
                                  <option value="S1 - Ilmu Komunikasi" <?php if($Mahasiswa->jurusan == 'S1 - Ilmu Komunikasi'): ?> selected <?php endif; ?>>S1 - Ilmu Komunikasi</option>
                                  <option value="D3 - Perhotelan" <?php if($Mahasiswa->jurusan == 'D3 - Perhotelan'): ?> selected <?php endif; ?>>D3 - Perhotelan</option>
                                  <option value="S1 - Hukum Bisnis" <?php if($Mahasiswa->jurusan == 'S1 - Hukum Bisnis'): ?> selected <?php endif; ?>>S1 - Hukum Bisnis</option>
                                </select>
                              </div>
                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Fakultas</label>
                                <select name="fakultas" class="form-control" id="fakultas">
                                  <option value="Kesehatan dan Pendidikan" <?php if($Mahasiswa->fakultas == 'Kesehatan dan Pendidikan'): ?> selected <?php endif; ?>>Kesehatan dan Pendidikan</option>
                                  <option value="Sains dan Teknologi" <?php if($Mahasiswa->fakultas == 'Sains dan Teknologi'): ?> selected <?php endif; ?>>Sains dan Teknologi</option>
                                  <option value="Komunikasi dan Bisnis" <?php if($Mahasiswa->fakultas == 'Komunikasi dan Bisnis'): ?> selected <?php endif; ?>>Komunikasi dan Bisnis</option>
                                </select>
                              </div>
                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Jenis Kelamin</label>
                                <select name="jenis_kelamin" class="form-control" id="jenis_kelamin">
                                  <option value="Laki-laki" <?php if($Mahasiswa->jenis_kelamin == 'Laki-laki'): ?> selected <?php endif; ?>>Laki-laki</option>
                                  <option value="Perempuan" <?php if($Mahasiswa->jenis_kelamin == 'Perempuan'): ?> selected <?php endif; ?>>Perempuan</option>
                                </select>
                              </div>
                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Alamat</label>
                                <input name="alamat" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                              </div>
                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Email</label>
                                <input name="email" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                              </div>
                              <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Angkatan</label>
                                <input name="angkatan" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                              </div>
                           
                          
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                       <button type="submit" class="btn btn-primary">Submit</button>
                      </form>
                    </div>
                  </div>
        </div>
     <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Project1-Khansa\resources\views/Mahasiswa/index.blade.php ENDPATH**/ ?>